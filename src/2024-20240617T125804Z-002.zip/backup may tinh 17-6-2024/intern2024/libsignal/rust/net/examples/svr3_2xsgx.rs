//
// Copyright 2023 Signal Messenger, LLC.
// SPDX-License-Identifier: AGPL-3.0-only
//
//! An example program that demonstrates how to implement 2-out-of-2 PPSS setup
//! using just a single enclave type (SGX in this case).
//!
//! One would need to provide a valid auth secret value used to authenticate to the enclave,
//! as well as the password that will be used to protect the data being stored. Since the
//! actual stored secret data needs to be exactly 32 bytes long, it is generated randomly
//! at each invocation instead of being passed via the command line.
use std::time::Duration;

use base64::prelude::{Engine, BASE64_STANDARD};
use clap::Parser;
use hex_literal::hex;
use libsignal_net::infra::dns::DnsResolver;
use nonzero_ext::nonzero;
use rand_core::{CryptoRngCore, OsRng, RngCore};

use attest::svr2::RaftConfig;
use libsignal_net::auth::Auth;
use libsignal_net::enclave::{
    EnclaveEndpoint, EnclaveEndpointConnection, MrEnclave, PpssSetup, Sgx, Svr3Flavor,
};
use libsignal_net::env::DomainConfig;
use libsignal_net::infra::certs::RootCertificates;
use libsignal_net::infra::tcp_ssl::DirectConnector as TcpSslTransportConnector;
use libsignal_net::svr::SvrConnection;
use libsignal_net::svr3::{OpaqueMaskedShareSet, PpssOps};

const TEST_SERVER_CERT: RootCertificates =
    RootCertificates::FromDer(include_bytes!("../res/sgx_test_server_cert.cer"));
const TEST_SERVER_RAFT_CONFIG: RaftConfig = RaftConfig {
    min_voting_replicas: 1,
    max_voting_replicas: 3,
    super_majority: 0,
    group_id: 5873791967879921865,
};
const TEST_SERVER_DOMAIN_CONFIG: DomainConfig = DomainConfig {
    hostname: "backend1.svr3.test.signal.org",
    ip_v4: &[],
    ip_v6: &[],
    cert: &TEST_SERVER_CERT,
    proxy_path: "/svr3-test",
};

pub struct TwoForTwoEnv<'a, A, B>(EnclaveEndpoint<'a, A>, EnclaveEndpoint<'a, B>)
where
    A: Svr3Flavor,
    B: Svr3Flavor;

impl<'a, A, B, S> PpssSetup<S> for TwoForTwoEnv<'a, A, B>
where
    A: Svr3Flavor + Send,
    B: Svr3Flavor + Send,
    S: Send,
{
    type Connections = (SvrConnection<A, S>, SvrConnection<B, S>);
    type ServerIds = [u64; 2];

    fn server_ids() -> Self::ServerIds {
        [0, 1]
    }
}

#[derive(Parser, Debug)]
struct Args {
    /// base64 encoding of the auth secret
    #[arg(long)]
    auth_secret: String,
    /// Password to be used to protect the data
    #[arg(long)]
    password: String,
}
#[tokio::main]
async fn main() {
    let args = Args::parse();

    let auth_secret: [u8; 32] = {
        BASE64_STANDARD
            .decode(&args.auth_secret)
            .expect("valid b64")
            .try_into()
            .expect("secret is 32 bytes")
    };

    let mut rng = OsRng;

    let mut make_uid = || {
        let mut bytes = [0u8; 16];
        rng.fill_bytes(&mut bytes[..]);
        bytes
    };

    let make_auth = |uid: [u8; 16]| Auth::from_uid_and_secret(uid, auth_secret);

    let two_sgx_env = {
        let endpoint = EnclaveEndpoint::<Sgx> {
            domain_config: TEST_SERVER_DOMAIN_CONFIG,
            mr_enclave: MrEnclave::new(&hex!(
                "acb1973aa0bbbd14b3b4e06f145497d948fd4a98efc500fcce363b3b743ec482"
            )),
        };
        TwoForTwoEnv(endpoint, endpoint)
    };

    let (uid_a, uid_b) = (make_uid(), make_uid());

    let connect = || async {
        let connector = TcpSslTransportConnector::new(DnsResolver::default());
        let connection_a = EnclaveEndpointConnection::with_custom_properties(
            two_sgx_env.0,
            Duration::from_secs(10),
            Some(&TEST_SERVER_RAFT_CONFIG),
        );

        let a = SvrConnection::connect(make_auth(uid_a), &connection_a, connector.clone())
            .await
            .expect("can attestedly connect");

        let connection_b = EnclaveEndpointConnection::with_custom_properties(
            two_sgx_env.1,
            Duration::from_secs(10),
            Some(&TEST_SERVER_RAFT_CONFIG),
        );

        let b = SvrConnection::connect(make_auth(uid_b), &connection_b, connector)
            .await
            .expect("can attestedly connect");
        (a, b)
    };

    let secret = make_secret(&mut rng);
    println!("Secret to be stored: {}", hex::encode(secret));

    let share_set_bytes = {
        let opaque_share_set = TwoForTwoEnv::backup(
            connect().await,
            &args.password,
            secret,
            nonzero!(10u32),
            &mut rng,
        )
        .await
        .expect("can multi backup");
        opaque_share_set.serialize().expect("can serialize")
    };
    println!("Share set: {}", hex::encode(&share_set_bytes));

    let restored = {
        let opaque_share_set =
            OpaqueMaskedShareSet::deserialize(&share_set_bytes).expect("can deserialize");
        TwoForTwoEnv::restore(connect().await, &args.password, opaque_share_set, &mut rng)
            .await
            .expect("can multi restore")
    };
    println!("Restored secret: {}", hex::encode(restored));

    assert_eq!(secret, restored);
}

fn make_secret(rng: &mut impl CryptoRngCore) -> [u8; 32] {
    let mut bytes = [0u8; 32];
    rng.fill_bytes(&mut bytes[..]);
    bytes
}
