If you've found a security vulnerability in Signal, please report it via email to
<security@signal.org>.

Please only use this address to report security flaws in the Signal application (including this
repository). For questions, support, or feature requests concerning the app, please submit a
[support request][] or join the [unofficial community forum][].

[support request]: https://support.signal.org/hc/requests/new
[unofficial community forum]: https://community.signalusers.org/
